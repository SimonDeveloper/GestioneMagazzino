﻿import $ from "jquery";
$(document).ready(() => { console.log('ciao') });
