import $ from "jquery";
$(document).ready(() => { console.log('ciao'); });
//# sourceMappingURL=file.js.map